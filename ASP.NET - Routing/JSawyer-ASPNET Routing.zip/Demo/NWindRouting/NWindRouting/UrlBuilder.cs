﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Routing;
using System.Web.Compilation;
using System.Web.UI;

namespace NWindRouting
{
    public static class UrlBuilder
    {
        public static string GetCategoryList()
        {

            var path = RouteTable.Routes.GetVirtualPath(
                null,
                "CategoryList",
                new RouteValueDictionary());
            return path.VirtualPath;
        }

        public static string GetSingleCategory(int categoryId)
        {
            return "~/ShowCategory.aspx?Id=" + categoryId.ToString();
        }

        public static string GetProductList()
        {


            return "~/Category/Products";

        }
        public static string GetProductsForCategory(int categoryId)
        {

            var values = new RouteValueDictionary();
            values.Add("C", categoryId);
            var path = RouteTable.Routes.GetVirtualPath(
                null,
                "ProductList",
                values);
            return path.VirtualPath;

        }
        public static string GetSingleProduct(int productId)
        {
            return "~/ViewProduct.aspx?Id=" + productId.ToString();
        }

        public static string GetCustomerOrders(string customerId)
        {
            return "~/ListOrders.aspx?Cu=" + customerId;
        }
        public static string GetOrderDetails(int orderId)
        {
            return "~/OrderDetails.aspx?Id=" + orderId.ToString();
        }
        public static string ViewCustomers()
        {
            return "~/Customers.aspx";
        }
    }


}
