﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration; 
namespace StaticRouting
{

    public class StaticRoutingConfigurationSection : ConfigurationSection
    {

        [ConfigurationProperty("Routes", IsDefaultCollection = true, IsRequired = true)]
        [ConfigurationCollection(typeof(StaticRoutingConfigurationCollection))]
        public StaticRoutingConfigurationCollection Routes
        {
            get
            {
                return (StaticRoutingConfigurationCollection)base["Routes"];
            }

            set
            {
                base["Routes"] = value;
            }
        }
    }

    public class StaticRoutingConfigurationCollection : ConfigurationElementCollection
    {
        protected override ConfigurationElement CreateNewElement()
        {
            return new StaticRoutingConfigurationElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            var routingElement = element as StaticRoutingConfigurationElement;
            if (routingElement != null)
            {
                return routingElement.Name;
            }
            else { return null; }
        }

        public StaticRoutingConfigurationElement this[int index]
        {
            get
            {
                return (StaticRoutingConfigurationElement)BaseGet(index);
            }
            set
            {
                if (BaseGet(index) != null)
                {
                    BaseRemoveAt(index);
                }
                BaseAdd(index, value);
            }
        }

        new public StaticRoutingConfigurationElement this[string Name]
        {
            get
            {
                return (StaticRoutingConfigurationElement)BaseGet(Name);
            }
        }
    }


    public class StaticRoutingConfigurationElement : ConfigurationElement
    {

        [ConfigurationProperty("name", IsRequired = true, IsKey = true)]
        public string Name
        {
            get { return (string)base["name"]; }
            set { base["name"] = value; }
        }

        [ConfigurationProperty("routeUrl", IsRequired = true)]
        public string RouteUrl
        {
            get { return (string)base["routeUrl"]; }
            set { base["routeUrl"] = value; }
        }

        [ConfigurationProperty("Defaults", IsRequired = false)]
        [ConfigurationCollection(typeof(NameValueConfigurationCollection))]
        public NameValueConfigurationCollection Defaults
        {
            get { return (NameValueConfigurationCollection)base["Defaults"]; }
            set { base["Defaults"] = value; }
        }

        [ConfigurationCollection(typeof(NameValueConfigurationCollection))]
        [ConfigurationProperty("Restrictions", IsRequired = false)]
        public NameValueConfigurationCollection Restrictions
        {
            get { return (NameValueConfigurationCollection)base["Restrictions"]; }
            set { base["Restrictions"] = value; }
        }

        [ConfigurationProperty("virtualPath", IsRequired = false, DefaultValue = null)]
        public string VirtualPath
        {
            get { return (string)base["virtualPath"]; }
            set { base["virtualPath"] = value; }
        }
    }

    
}
