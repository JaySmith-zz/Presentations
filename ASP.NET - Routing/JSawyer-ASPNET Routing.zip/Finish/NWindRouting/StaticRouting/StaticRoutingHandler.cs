﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Routing;
using System.Web;
using System.Web.UI;
using System.Web.Compilation;
using System.Configuration; 
namespace StaticRouting
{
    public class StaticRoutingHandler : IRouteHandler
    {

        public static void Configure(RouteCollection routes)
        {
            //Get the section
            StaticRoutingConfigurationSection section =
                ConfigurationManager.GetSection("StaticRoutes") as StaticRoutingConfigurationSection;
            if (section == null) { return; }

            foreach (StaticRoutingConfigurationElement item in section.Routes)
            {
                routes.Add(item.Name, GetRouteForElement(item)); 
            }

        }

        public static Route GetRouteForElement(StaticRoutingConfigurationElement element)
        {

            IRouteHandler handler;
            RouteValueDictionary defaults = new RouteValueDictionary();
            RouteValueDictionary restrictions = new RouteValueDictionary(); 

            if (String.IsNullOrEmpty(element.VirtualPath))
            {
                //Stop Route ... 
                handler = new StopRoutingHandler();
            }
            else
            {
                handler = new StaticRoutingHandler(element.VirtualPath); 
            }

            foreach (NameValueConfigurationElement item in element.Defaults)
            {
                defaults.Add(item.Name, item.Value); 
            }


            foreach (NameValueConfigurationElement item in element.Restrictions)
            {
                restrictions.Add(item.Name, item.Value); 
            }

            return new Route(element.RouteUrl,
                defaults, restrictions, handler); 
        }

        public StaticRoutingHandler(string virtualPath)
        {
            this.VirtualPath = virtualPath;
        }

        public string VirtualPath { get; private set; }

        #region IRouteHandler Members

        public IHttpHandler GetHttpHandler(RequestContext requestContext)
        {
            string finalPath = VirtualPath;
            if (requestContext.RouteData.Values.Count > 0)
            {
                List<string> values = new List<string>();
                //Add these to the virtual path as QS arguments
                foreach (var item in requestContext.RouteData.Values)
                {
                    values.Add(item.Key + "=" + item.Value);
                }
                finalPath += "?" + String.Join("&", values.ToArray());

            }

            //Rewrite the path to pass the query string values. 
            HttpContext.Current.RewritePath(finalPath);

            var page = BuildManager.CreateInstanceFromVirtualPath(
                VirtualPath, typeof(Page)) as IHttpHandler;
            return page;
        }


        #endregion
    }
}
