﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Routing;
using System.Web.Compilation;
using System.Web.UI;

namespace NWindRouting
{
    public static class UrlBuilder
    {
        public static string GetCategoryList()
        {
            var path = RouteTable.Routes.GetVirtualPath(
                null,
                "CategoryList",
                new RouteValueDictionary());
            return path.VirtualPath;
        }

        public static string GetSingleCategory(int categoryId)
        {
            return "~/ShowCategory.aspx?Id=" + categoryId.ToString();
        }

        public static string GetProductList()
        {
            var path = RouteTable.Routes.GetVirtualPath(
                null,
                "ProductList",
                new RouteValueDictionary());
            return path.VirtualPath;

        }
        public static string GetProductsForCategory(int categoryId)
        {

            var values = new RouteValueDictionary();
            values.Add("C", categoryId);

            var path = RouteTable.Routes.GetVirtualPath(
                null,
                "ProductList",
                values);
            return path.VirtualPath;

        }
        public static string GetSingleProduct(int productId)
        {
            var values = new RouteValueDictionary();
            values.Add("P", productId);

            var path = RouteTable.Routes.GetVirtualPath(
                null,
                "ViewProduct",
                values);
            return path.VirtualPath;
            
        }

        public static string GetCustomerOrders(string customerId)
        {
            var values = new RouteValueDictionary();
            values.Add("Cu", customerId);

            var path = RouteTable.Routes.GetVirtualPath(
                null,
                "CustomerOrders",
                values);
            return path.VirtualPath;
        }
        public static string GetOrderDetails(int orderId)
        {
            var values = new RouteValueDictionary();
            values.Add("Id", orderId);

            var path = RouteTable.Routes.GetVirtualPath(
                null,
                "OrderDetails",
                values);
            return path.VirtualPath;
        }
        public static string ViewCustomers(string customerId)
        {
            var path = RouteTable.Routes.GetVirtualPath(
                null,
                "CustomerList",
                new RouteValueDictionary());
            return path.VirtualPath;

        }
    }

    
}
