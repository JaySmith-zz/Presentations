﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Web.Routing;

namespace NWindRouting
{
    public class Global : System.Web.HttpApplication
    {

        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.Clear();

            //routes.Add(new Route("{resource}.axd/{*pathInfo}", new StopRoutingHandler()));
            //routes.Add("CategoryList", new Route("Categories", new StaticRoutingHandler("~/CategoryList.aspx")));

            //RouteValueDictionary productListRestrictions = new RouteValueDictionary();
            //productListRestrictions.Add("C", "\\d");
            //routes.Add("ProductList", new Route("Category/Products/{C}",
            //    null, productListRestrictions,
            //    new StaticRoutingHandler("~/ProductList.aspx")));
            

            //routes.Add(new Route("{*path}", new StaticRoutingHandler("~/default.aspx")));
            StaticRouting.StaticRoutingHandler.Configure(routes); 

        }

        protected void Application_Start(object sender, EventArgs e)
        {
            RegisterRoutes(RouteTable.Routes);
        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}