﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NWindRouting
{
    public static class UrlBuilder
    {
        public static string GetCategoryList()
        {
            return "~/CategoryList.aspx"; 
        }

        public static string GetSingleCategory(int categoryId)
        {
            return "~/ShowCategory.aspx?Id=" + categoryId.ToString(); 
        }

        public static string GetProductList()
        {
            return "~/ProductList.aspx"; 
        }
        public static string GetProductsForCategory(int categoryId)
        {
            return "~/ProductList.aspx?C=" + categoryId.ToString(); 

        }
        public static string GetSingleProduct(int productId)
        {
            return "~/ViewProduct.aspx?Id=" + productId.ToString(); 
        }

        public static string GetCustomerOrders(string customerId)
        {
            return "~/ListOrders.aspx?Cu=" + customerId;
        }
        public static string GetOrderDetails(int orderId)
        {
            return "~/OrderDetails.aspx?Id=" + orderId.ToString(); 
        }
        public static string ViewCustomers(string customerId)
        {
            return "~/Customers.aspx";
        }
    }
}
