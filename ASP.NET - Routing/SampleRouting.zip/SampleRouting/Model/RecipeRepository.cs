﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Linq;
using System.IO;

namespace SampleRouting.Model
{
    public class RecipeRepository
    {
        public RecipeRepository()
        {
            string path = HttpContext.Current.Server.MapPath(
                        "~/App_Data/recipes.xml");
            using (var reader = new StreamReader(path))
            {
                _recipes = XDocument.Load(reader);
            }        
        }

        public RecipeRepository(XDocument document)
        {
            _recipes = document;
        }

        public Recipe GetRecipe(string name)
        {
            Recipe result = null;
            var query =
                    _recipes.Element("recipes")
                            .Elements("recipe")
                            .FirstOrDefault(recipe => recipe.Attribute("name").Value.ToLower() == name.ToLower());

            if (query != null)
            {
                result = new Recipe {
                    Name = query.Attribute("name").Value,
                    Ingredients = query.Element("ingredients").Value,
                    Instructions = query.Element("directions").Value
                };
            }

            return result;
        }

        public IEnumerable<string> GetAllRecipeNames()
        {
            return 
                _recipes.Element("recipes")
                        .Elements("recipe")
                        .Select(recipe => recipe.Attribute("name").Value);
        }

        XDocument _recipes;
    }
}
