﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SampleRouting.Model;
using System.Web.Routing;

namespace SampleRouting
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var recipes = 
                    new RecipeRepository()
                        .GetAllRecipeNames()
                        .OrderBy(recipeName => recipeName)
                        .Select(recipeName =>
                          new
                          {
                            Name = recipeName,
                            Url = GetVirtualPathForRecipe(recipeName)
                          });

                

                _recipeList.DataSource = recipes;
                _recipeList.DataBind();
            }
        }

        protected string GetVirtualPathForRecipe(string recipeName)
        {
            VirtualPathData pathData = 
                RouteTable.Routes.GetVirtualPath(
                                    null,
                                    "Recipe",
                                    new RouteValueDictionary { { "Name", recipeName } });
            
            return pathData.VirtualPath;
        }
    }
}
