﻿using System;
using System.Web;

namespace SampleRouting.Routing
{
    interface IRecipeDisplay : IHttpHandler
    {
        string RecipeName { get;  set; }
    }
}
