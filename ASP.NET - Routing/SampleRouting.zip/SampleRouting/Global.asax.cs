﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Web.Routing;
using SampleRouting.Routing;

namespace SampleRouting
{
    public class Global : System.Web.HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            RegisterRoutes();
        }

        private static void RegisterRoutes()
        {
            RouteTable.Routes.Add(
                "Recipe",
                new Route("recipe/{name}", 
                          new RecipeRouteHandler(
                              "~/WebForms/RecipeDisplay.aspx")));
        }
    }
}