﻿using System;
using SampleRouting.Model;
using SampleRouting.Routing;
using System.Web.UI;

namespace SampleRouting.WebForms
{
    public partial class RecipeDisplay : Page, IRecipeDisplay
    {
        public string RecipeName { get; set; }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if (!IsPostBack)
            {
                var recipe = new RecipeRepository().GetRecipe(RecipeName);
                if (recipe != null)
                {
                    _name.Text = recipe.Name;
                    _ingredients.Text = recipe.Ingredients;
                    _instructions.Text = recipe.Instructions;
                }                
            }
        }       
    }
}
