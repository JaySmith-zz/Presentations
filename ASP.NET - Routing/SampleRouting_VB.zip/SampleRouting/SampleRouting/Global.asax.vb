Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.Security
Imports System.Web.SessionState
Imports System.Web.Routing
Imports SampleRouting.Routing

Namespace SampleRouting
	Public Class [Global]
		Inherits System.Web.HttpApplication
		Protected Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)
			RegisterRoutes()
		End Sub

		Private Shared Sub RegisterRoutes()
			RouteTable.Routes.Add("Recipe", New Route("recipe/{name}", New RecipeRouteHandler("~/WebForms/RecipeDisplay.aspx")))
		End Sub
	End Class
End Namespace