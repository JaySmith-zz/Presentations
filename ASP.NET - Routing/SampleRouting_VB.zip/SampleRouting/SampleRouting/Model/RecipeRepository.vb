Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Xml.Linq
Imports System.IO

Namespace SampleRouting.Model
	Public Class RecipeRepository
		Public Sub New()
			Dim path As String = HttpContext.Current.Server.MapPath("~/App_Data/recipes.xml")
			Using reader = New StreamReader(path)
				_recipes = XDocument.Load(reader)
			End Using
		End Sub

		Public Sub New(ByVal document As XDocument)
			_recipes = document
		End Sub

		Public Function GetRecipe(ByVal name As String) As Recipe
			Dim result As Recipe = Nothing
			Dim query = _recipes.Element("recipes").Elements("recipe").FirstOrDefault(Function(recipe) recipe.Attribute("name").Value.ToLower() = name.ToLower())

			If query IsNot Nothing Then
				result = New Recipe With {.Name = query.Attribute("name").Value, .Ingredients = query.Element("ingredients").Value, .Instructions = query.Element("directions").Value}
			End If

			Return result
		End Function

		Public Function GetAllRecipeNames() As IEnumerable(Of String)
			Return _recipes.Element("recipes").Elements("recipe").Select(Function(recipe) recipe.Attribute("name").Value)
		End Function

		Private _recipes As XDocument
	End Class
End Namespace
