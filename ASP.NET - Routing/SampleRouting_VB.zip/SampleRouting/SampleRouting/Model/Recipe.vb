Imports Microsoft.VisualBasic
Imports System

Namespace SampleRouting.Model
	Public Class Recipe
		Private privateName As String
		Public Property Name() As String
			Get
				Return privateName
			End Get
			Set(ByVal value As String)
				privateName = value
			End Set
		End Property
		Private privateIngredients As String
		Public Property Ingredients() As String
			Get
				Return privateIngredients
			End Get
			Set(ByVal value As String)
				privateIngredients = value
			End Set
		End Property
		Private privateInstructions As String
		Public Property Instructions() As String
			Get
				Return privateInstructions
			End Get
			Set(ByVal value As String)
				privateInstructions = value
			End Set
		End Property
	End Class
End Namespace
