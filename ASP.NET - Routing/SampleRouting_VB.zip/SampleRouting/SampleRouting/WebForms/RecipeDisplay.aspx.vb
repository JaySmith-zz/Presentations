Imports Microsoft.VisualBasic
Imports System
Imports SampleRouting.Model
Imports SampleRouting.Routing
Imports System.Web.UI

Namespace SampleRouting.WebForms
	Partial Public Class RecipeDisplay
		Inherits Page
		Implements IRecipeDisplay
		Private privateRecipeName As String
		Public Property RecipeName() As String Implements IRecipeDisplay.RecipeName
			Get
				Return privateRecipeName
			End Get
			Set(ByVal value As String)
				privateRecipeName = value
			End Set
		End Property

		Protected Overrides Sub OnLoad(ByVal e As EventArgs)
			MyBase.OnLoad(e)
			If (Not IsPostBack) Then
				Dim recipe = New RecipeRepository().GetRecipe(RecipeName)
				If recipe IsNot Nothing Then
					_name.Text = recipe.Name
					_ingredients.Text = recipe.Ingredients
					_instructions.Text = recipe.Instructions
				End If
			End If
		End Sub
	End Class
End Namespace
