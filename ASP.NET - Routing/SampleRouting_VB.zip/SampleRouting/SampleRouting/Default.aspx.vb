Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports SampleRouting.Model
Imports System.Web.Routing

Namespace SampleRouting
	Partial Public Class [Default]
		Inherits System.Web.UI.Page
		Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
			If (Not IsPostBack) Then
                Dim recipes = New RecipeRepository().GetAllRecipeNames(). _
                    OrderBy(Function(recipeName) recipeName). _
                        Select(Function(recipeName) New With {Key .Name = recipeName, Key .Url = GetVirtualPathForRecipe(recipeName)})

				_recipeList.DataSource = recipes
				_recipeList.DataBind()
			End If
		End Sub

        Protected Function GetVirtualPathForRecipe(ByVal recipeName As String) As String
            Dim routes As New RouteValueDictionary
            routes.Add("Name", recipeName)

            Dim pathData As VirtualPathData = RouteTable.Routes.GetVirtualPath(Nothing, "Recipe", routes)

            Return pathData.VirtualPath
        End Function
	End Class
End Namespace
