Imports Microsoft.VisualBasic
Imports System.Web
Imports System.Web.Compilation
Imports System.Web.Routing
Imports System.Web.UI
Imports SampleRouting.WebForms
Imports System.Web.Security
Imports System.Security
Imports System.Net

Namespace SampleRouting.Routing
	Public Class RecipeRouteHandler
		Implements IRouteHandler
		Public Sub New(ByVal virtualPath As String)
			_virtualPath = virtualPath
		End Sub

		Public Function GetHttpHandler(ByVal requestContext As RequestContext) As IHttpHandler Implements IRouteHandler.GetHttpHandler
			If (Not UrlAuthorizationModule.CheckUrlAccessForPrincipal(_virtualPath, requestContext.HttpContext.User, requestContext.HttpContext.Request.HttpMethod)) Then
				requestContext.HttpContext.Response.StatusCode = CInt(Fix(HttpStatusCode.Unauthorized))
				requestContext.HttpContext.Response.End()
			End If

			Dim display = TryCast(BuildManager.CreateInstanceFromVirtualPath(_virtualPath, GetType(Page)), IRecipeDisplay)

			display.RecipeName = TryCast(requestContext.RouteData.Values("name"), String)
			Return display
		End Function

		Private _virtualPath As String
	End Class
End Namespace
