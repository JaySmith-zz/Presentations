Imports Microsoft.VisualBasic
Imports System
Imports System.Web

Namespace SampleRouting.Routing
	Friend Interface IRecipeDisplay
	Inherits IHttpHandler
		Property RecipeName() As String
	End Interface
End Namespace
