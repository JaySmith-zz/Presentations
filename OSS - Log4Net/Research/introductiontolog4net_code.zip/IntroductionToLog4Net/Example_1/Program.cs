﻿#region Using Directives

using System;
using System.Collections.Generic;
using System.Threading;
using Alteridem.CodeCamp.Algorithms;
using Alteridem.CodeCamp.Data;

#endregion

namespace Alteridem.CodeCamp
{
   /// <summary>
   /// Introduction to log4net - Toronto CodeCamp 2008
   /// Author: Rob Prouse rob@prouse.org
   ///         http://www.alteridem.net
   /// </summary>
   class Program
   {
      private static readonly object _consoleLock = new object();
      private const int THREADS = 5;

      internal static void Main()
      {
         try
         {
            Thread.CurrentThread.Name = "Main";

            Console.WriteLine( "Starting Program" );

            Thread[] threads = new Thread[THREADS];

            // Launch each of the threads.
            for ( int i = 0; i < THREADS; i++ )
            {
               threads[i] = new Thread( Run );
               threads[i].Start();
            }

            // Wait for each of the threads to finish
            for ( int i = 0; i < THREADS; i++ )
            {
               threads[i].Join();
            }

            Console.WriteLine( "Press enter to exit the program" );
            Console.ReadLine();

            Console.WriteLine( "Exiting Program" );
         }
         catch ( Exception ex )
         {
            Console.WriteLine( "Unhandled exception caught, program exiting. Error: {0}", ex.Message );
            throw;
         }
      }

      private static void Run()
      {
         try
         {
            int[] array = RandomArrayGenerator.CreateArray( 10, 100 );
            OutputArray( "Unsorted", array );
            QuickSort<int>.Sort( array );
            OutputArray( "Sorted", array );
         }
         catch ( Exception ex )
         {
            Console.WriteLine( "Unhandled exception caught, aborting thread. Error: {0}", ex.Message );
         }
      }

      private static void OutputArray<T>( string message, IEnumerable<T> array )
      {
         if ( array == null )
            throw new ArgumentNullException( "array" );

         lock ( _consoleLock )
         {
            Console.Write( "TID:{0} {1}:", Thread.CurrentThread.ManagedThreadId, message );
            foreach ( T t in array )
            {
               Console.Write( "{0} ", t );
            }
            Console.WriteLine();
         }
      }
   }
}
