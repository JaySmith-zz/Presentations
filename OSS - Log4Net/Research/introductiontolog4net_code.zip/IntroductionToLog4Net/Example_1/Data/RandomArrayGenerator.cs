﻿#region Using Directives

using System;

#endregion

namespace Alteridem.CodeCamp.Data
{
   /// <summary>
   /// Introduction to log4net - Toronto CodeCamp 2008
   /// Author: Rob Prouse rob@prouse.org
   ///         http://www.alteridem.net
   /// </summary>
   public static class RandomArrayGenerator
   {
      private static readonly Random _rand = new Random();

      /// <summary>
      /// Generates a random array of ints
      /// </summary>
      public static int[] CreateArray( int length, int max )
      {
         if ( length < 0 )
            throw new ArgumentException( "length must not be less than 0" );

         if ( max <= 0 )
            throw new ArgumentException( "max must be greater than 0" );

         int[] array = new int[length];
         for ( int i = 0; i < length; i++ )
         {
            array[i] = _rand.Next( 0, max );
         }
         return array;
      }
   }
}
