﻿#region Using Directives

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;
using Alteridem.CodeCamp.Algorithms;
using Alteridem.CodeCamp.Data;
using log4net;
using System.Text;

#endregion

namespace Alteridem.CodeCamp
{
   /// <summary>
   /// Introduction to log4net - Toronto CodeCamp 2008
   /// Author: Rob Prouse rob@prouse.org
   ///         http://www.alteridem.net
   /// </summary>
   class Program
   {
      //private static readonly ILog log = LogManager.GetLogger( "Alteridem.CodeCamp.Program" );
      //private static readonly ILog log = LogManager.GetLogger( typeof( Program ) );
      private static readonly ILog log = LogManager.GetLogger( MethodBase.GetCurrentMethod().DeclaringType );

      private const int THREADS = 5;

      internal static void Main()
      {
         try
         {
            Thread.CurrentThread.Name = "Main";

            log.Info( "Starting Program" );

            Thread[] threads = new Thread[THREADS];

            // Launch each of the threads.
            for ( int i = 0; i < THREADS; i++ )
            {
               threads[i] = new Thread( Run );
               threads[i].Start();
            }

            // Wait for each of the threads to finish
            for ( int i = 0; i < THREADS; i++ )
            {
               log.DebugFormat( "Waiting for thread {0}", threads[i].ManagedThreadId );
               threads[i].Join();
               log.DebugFormat( "Joined thread {0}", threads[i].ManagedThreadId );
            }

            Console.WriteLine( "Press enter to exit the program" );
            Console.ReadLine();

            log.Info( "Exiting Program" );
         }
         catch ( Exception ex )
         {
            log.Fatal( "Unhandled exception caught, program exiting", ex );
            throw;
         }
      }

      private static void Run()
      {
         try
         {
            int[] array = RandomArrayGenerator.CreateArray( 10, 100 );
            OutputArray( "Unsorted", array );
            QuickSort<int>.Sort( array );
            OutputArray( "Sorted", array );
         }
         catch ( Exception ex )
         {
            log.Fatal( "Unhandled exception caught, aborting thread", ex );
         }
      }

      private static void OutputArray<T>( string message, IEnumerable<T> array )
      {
         if ( array == null )
            throw new ArgumentNullException( "array" );

         if ( log.IsInfoEnabled )
         {
            StringBuilder builder = new StringBuilder( message );
            builder.Append( " " );
            foreach ( T t in array )
            {
               builder.AppendFormat( "{0} ", t );
            }
            log.Info( builder );
         }
      }
   }
}
