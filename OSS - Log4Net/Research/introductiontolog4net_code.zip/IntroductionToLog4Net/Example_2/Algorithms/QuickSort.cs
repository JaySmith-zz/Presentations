﻿#region Using Directives

using System;
using System.Reflection;
using log4net;

#endregion

namespace Alteridem.CodeCamp.Algorithms
{
   /// <summary>
   /// Introduction to log4net - Toronto CodeCamp 2008
   /// Author: Rob Prouse rob@prouse.org
   ///         http://www.alteridem.net
   /// </summary>
   public static class QuickSort<T> where T : IComparable
   {
      private static readonly ILog log = LogManager.GetLogger( "Alteridem.CodeCamp.Algorithms.QuickSort" );

      /// <summary>
      /// Sorts the elements in an array using the Quick Sort algorithm
      /// </summary>
      /// <param name="array"></param>
      public static void Sort( T[] array )
      {
         if ( array == null )
         {
            log.Error( "array argument in QuickSort.Sort must not be null" );
            throw new ArgumentNullException( "array" );
         }

         Sort( array, 0, array.Length - 1 );
      }

      private static void Sort( T[] array, int start, int end )
      {
         if ( array == null )
         {
            log.Error( "array argument in QuickSort.Sort must not be null" );
            throw new ArgumentNullException( "array" );
         }

         log.DebugFormat( "QuickSort.Sort( array.Length={0}, start={1}, end={2} )", array.Length, start, end );

         int i = start;  // index of left-to-right scan
         int k = end;    // index of right-to-left scan

         // Make sure we have at least two elements left to sort, else we are done
         if ( end - start >= 1 )
         {
            // Set the pivot to the first element
            T pivot = array[start];

            // Continue until the two indices cross
            while ( k > i )
            {
               // From the left, find first element greater than the pivot
               while ( array[i].CompareTo( pivot ) <= 0 && i <= end && k > i )
               {
                  i++;
               }

               // From the right, find the first element not greater than the pivot
               while ( array[k].CompareTo( pivot ) > 0 && k >= start && k >= i )
               {
                  k--;
               }

               // If we have not crossed indices, swap
               if ( k > i )
               {
                  Swap( array, i, k );
               }
            }
            // Swap the last element in the left partition with the pivot 
            Swap( array, start, k );

            // Recurse and quicksorting the left/right partitions
            Sort( array, start, k - 1 );
            Sort( array, k + 1, end );
         }
      }

      /// <summary>
      /// Swaps two elements in an array
      /// </summary>
      private static void Swap( T[] array, int i1, int i2 )
      {
         if ( array == null )
         {
            log.Error( "array argument in QuickSort.Swap must not be null" );
            throw new ArgumentNullException( "array" );
         }

         if ( i1 < 0 || i1 >= array.Length )
         {
            log.Error( "i2 argument in QuickSort.Swap must be in the range 0 and array.Length" );
            throw new ArgumentException( "i1 must be in the range 0 and array.Length" );
         }

         if ( i2 < 0 || i2 >= array.Length )
         {
            log.Error( "i2 argument in QuickSort.Swap must be in the range 0 and array.Length" );
            throw new ArgumentException( "i2 must be in the range 0 and array.Length" );
         }

         log.DebugFormat( "QuickSort.Swap( array.Length={0}, i1={1}, i2={2} )", array.Length, i1, i2 );

         T temp = array[i1];
         array[i1] = array[i2];
         array[i2] = temp;
      }
   }
}
