========================================================
Markdown.NET --- a C# port of the original Markdown code
========================================================

ver 0.2.0.0 - Initial release
ver 1.0.1.7 - Code fixes to sync up with ver. 1.0.1b7 of the original Markdown
ver 1.0.1   - Code fixes to sync up with ver. 1.0.1 of the original Markdown. Also
              from now on the code and binaries comes with a BSD license.
