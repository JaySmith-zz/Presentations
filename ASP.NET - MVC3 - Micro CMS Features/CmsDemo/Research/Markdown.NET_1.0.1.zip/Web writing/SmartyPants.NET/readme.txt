===============================================================
SmartyPants.NET --- a C# port of the original SmartyPants code
===============================================================

ver 1.5.1.0 - Initial public release
              Code is in sync with ver. 1.5.1 of the original SmartyPants