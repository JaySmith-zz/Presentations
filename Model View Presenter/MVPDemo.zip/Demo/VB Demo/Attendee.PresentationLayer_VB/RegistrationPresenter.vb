Imports Attendee.PresentationLayer_VB

Public Class RegistrationPresenter

    Private _view As IRegistrationView

    Public Sub New(ByVal view As IRegistrationView)

        Me._view = view
        Me.Initialize()

    End Sub

    Private Sub Initialize()

        ' Register the event handlers
        AddHandler Me._view.Initialize, AddressOf _view_Initialize
        AddHandler Me._view.RegistserUser, AddressOf _view_RegisterUser

    End Sub

    Private Sub _view_Initialize(ByVal sender As Object, ByVal e As EventArgs)

        'Initialize the Age to the default value of 5
        _view.Age = 5

    End Sub

    Private Sub _view_RegisterUser(ByVal sender As Object, ByVal e As EventArgs)

        ' Register the User and retur the the page
        _view.RegistsrationSuccessful = True

    End Sub

End Class
