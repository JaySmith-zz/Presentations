Imports Attendee.PresentationLayer_VB

Public Interface IRegistrationView

    ReadOnly Property FirstName() As String
    ReadOnly Property LastName() As String
    Property Age() As String

    WriteOnly Property RegistsrationSuccessful() As Boolean

    Event Initialize As EventHandler(Of EventArgs)
    Event RegistserUser As EventHandler(Of EventArgs)

End Interface
