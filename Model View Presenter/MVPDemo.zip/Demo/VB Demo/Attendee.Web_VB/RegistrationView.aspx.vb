Imports Attendee.PresentationLayer_VB

Partial Public Class _Default
    Inherits System.Web.UI.Page
    Implements IRegistrationView

    Private _presenter As RegistrationPresenter

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        _presenter = New RegistrationPresenter(Me)

        If Not (IsPostBack) Then
            RaiseEvent Initialize(Me, EventArgs.Empty)
        End If
    End Sub

    Public ReadOnly Property FirstName() As String Implements IRegistrationView.FirstName
        Get
            Return TextBoxFirstName.Text
        End Get
    End Property

    Public ReadOnly Property LastName() As String Implements IRegistrationView.LastName
        Get
            Return TextBoxLastName.Text
        End Get
    End Property

    Public Property Age() As String Implements IRegistrationView.Age
        Get
            Return System.Convert.ToInt32(TextBoxAge.Text)
        End Get
        Set(ByVal value As String)
            TextBoxAge.Text = value.ToString()
        End Set
    End Property

    Public WriteOnly Property RegistrationSuccessfull() As Boolean Implements IRegistrationView.RegistsrationSuccessful
        Set(ByVal value As Boolean)

            'Display the Thank You screen
            Response.Redirect("ThankYou.aspx")

        End Set
    End Property

    Public Event Initialize(ByVal sender As Object, ByVal e As System.EventArgs) Implements IRegistrationView.Initialize
    Public Event RegisterUser(ByVal sender As Object, ByVal e As System.EventArgs) Implements IRegistrationView.RegistserUser

    Protected Sub ButtonRegister_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonRegister.Click
        RaiseEvent RegisterUser(Me, EventArgs.Empty)
    End Sub
End Class