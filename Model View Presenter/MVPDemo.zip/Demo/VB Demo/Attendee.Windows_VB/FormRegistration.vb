Imports Attendee.PresentationLayer_VB

Public Class FormRegistration
    Implements IRegistrationView

    Private _presenter As RegistrationPresenter

    Private Sub FormRegistration_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        _presenter = New RegistrationPresenter(Me)

        RaiseEvent Initialize(Me, EventArgs.Empty)

    End Sub

    Public ReadOnly Property FirstName() As String Implements IRegistrationView.FirstName
        Get
            Return TextBoxFirstName.Text
        End Get
    End Property

    Public ReadOnly Property LastName() As String Implements IRegistrationView.LastName
        Get
            Return TextBoxLastName.Text
        End Get
    End Property

    Public Property Age() As String Implements IRegistrationView.Age
        Get
            Return System.Convert.ToInt32(TextBoxAge.Text)
        End Get
        Set(ByVal value As String)
            TextBoxAge.Text = value.ToString()
        End Set
    End Property

    Public WriteOnly Property RegistrationSuccessfull() As Boolean Implements IRegistrationView.RegistsrationSuccessful
        Set(ByVal value As Boolean)

            'Display the Thank You screen
            MessageBox.Show("Thank You!")

        End Set
    End Property

    Public Event Initialize(ByVal sender As Object, ByVal e As System.EventArgs) Implements IRegistrationView.Initialize
    Public Event RegisterUser(ByVal sender As Object, ByVal e As System.EventArgs) Implements IRegistrationView.RegistserUser

    Private Sub buttonRegister_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles buttonRegister.Click

        ' Raise the Register User event to handeled by the presenter
        RaiseEvent RegisterUser(Me, EventArgs.Empty)

    End Sub
End Class
