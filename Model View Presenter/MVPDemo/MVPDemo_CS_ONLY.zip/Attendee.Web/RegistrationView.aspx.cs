using System;
using System.Web.UI;

namespace Attendee.Web
{
    //TODO: Implement the IRegistrationView
    public partial class RegistrationView : Page
    {
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
        }

        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                // Set the Focus to the First Name TextBox
                TextBoxFirstName.Focus();
            }
        }

        protected void ButtonRegister_Click(object sender, EventArgs e)
        {
            BusinessLayer_CS.Attendee newAttendee = new BusinessLayer_CS.Attendee();
            
            newAttendee.FirstName = TextBoxFirstName.Text;
            newAttendee.LastName = TextBoxLastName.Text;
            newAttendee.Age = Convert.ToInt32(TextBoxAge.Text);

            if (newAttendee.Save())
                Server.Transfer("ThankYou.aspx");
                
        }

    }
}
