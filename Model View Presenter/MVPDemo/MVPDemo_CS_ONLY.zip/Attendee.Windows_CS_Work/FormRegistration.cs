using System;
using System.Windows.Forms;
//TODO: Step 1: Add reference to Attendee.PresentationLayer_CS

namespace Attendee.Windows_CS
{
    //TODO: Step 2 Implement the IRegistrationView interface
    public partial class FormRegistration : Form
    {
        //TODO: Step 4: create variable to hold reference to presenter

        public FormRegistration()
        {
            //TODO: Create presenter object

            InitializeComponent();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            //TODO: Step 5: Initialize the RegistrationPresenter 
            


            //TODO: Step 6: Raise the Initialize Event to be handled by the presenter
            
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            //TODO: Step 7: Raise the Register User Event to be handled by the Presenter
            
        }

        //TODO: Step 3: Wireup interface
//        #region IRegistrationView Members
//
//        public string FirstName
//        {
//            get { return textBoxFirstName.Text; }
//        }
//
//        public string LastName
//        {
//            get { return textBoxLastName.Text; }
//        }
//
//        public int Age
//        {
//            get { return System.Convert.ToInt32(textBoxAge.Text); }
//            set { textBoxAge.Text = value.ToString(); }
//        }
//
//        public bool RegistrationSuccessful
//        {
//            set
//            {
//                if (value)
//                    MessageBox.Show("Registartion Successfull...");
//                else
//                    MessageBox.Show("Registration failure...");
//            }
//        }
//
//        public event EventHandler<EventArgs> Initialize;
//
//        public event EventHandler<EventArgs> RegisterUser;
//
//        #endregion
    }
}