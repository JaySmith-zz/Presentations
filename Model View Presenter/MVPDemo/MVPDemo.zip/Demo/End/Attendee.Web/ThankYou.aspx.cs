using System;
using System.Web.UI;

namespace Attendee.Web_CS
{
    public partial class ThankYou : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
